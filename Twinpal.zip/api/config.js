module.exports={
    jwtSecret:"Somejsonwebtokensecret"
}